# 🎮 AI Party Hub — MVP

Voice Mafia game with automated game master. Play with 4-16 friends online.

## 🚀 Quick Start (GitHub Codespaces)

1. Click **"Code"** → **"Codespaces"** → **"Create codespace on main"**
2. Wait for setup (Flutter + Node.js auto-install)
3. Backend starts automatically on port 3000

## 📁 Project Structure

```
aipartyhub/
├── backend/          # Node.js + Socket.io API
│   ├── src/server.js # Main game logic
│   └── package.json
├── flutter/          # Flutter mobile app
│   ├── lib/
│   │   ├── main.dart
│   │   ├── screens/  # Home, Lobby, Game
│   │   └── services/ # GameService, Socket.io
│   └── pubspec.yaml
└── supabase/
    └── schema.sql    # Database schema
```

## ⚙️ Setup

### 1. Supabase (Database)

1. Go to [supabase.com](https://supabase.com) → New Project
2. Copy **Project URL** and **anon key** from Settings → API
3. Run `supabase/schema.sql` in SQL Editor

### 2. Backend

```bash
cd backend
cp .env.example .env
# Edit .env with your Supabase credentials
npm install
npm run dev
```

### 3. Flutter App

```bash
cd flutter
flutter pub get
# Edit lib/main.dart with your Supabase credentials
flutter run
```

## 🎮 Features

- ✅ Create/Join lobby with code
- ✅ Host configurable settings (timers, roles, max players)
- ✅ Automated Game Master (no human host needed)
- ✅ Role assignment: Mafia, Doctor, Detective, Villager
- ✅ Night/Day phases with timers
- ✅ Voting system with live tally
- ✅ Ghost chat for eliminated players
- ✅ Role reveal: Immediate or Hidden
- ✅ 4-16 players support

## 🗺️ Roadmap

| Phase | Feature |
|-------|---------|
| MVP | Text-based Mafia (this) |
| v1.1 | Voice chat (Agora) |
| v1.2 | Sound effects & animations |
| v1.3 | More games (Spyfall, Avalon) |
| v2.0 | AI Game Master |
| v2.1 | AI Mission Challenge mode |
| v3.0 | Steam release (Unity) |

## 🛠️ Tech Stack

| Layer | Technology |
|-------|-----------|
| Mobile | Flutter |
| Backend | Node.js + Socket.io |
| Database | PostgreSQL (Supabase) |
| Auth | Supabase Auth (Anonymous) |
| Voice | Agora (future) |

## 📄 License

MIT

require('dotenv').config();
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');
const { createClient } = require('@supabase/supabase-js');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST']
  }
});

// Supabase client
const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
);

app.use(cors());
app.use(express.json());

// Health check
app.get('/', (req, res) => {
  res.json({ status: 'AI Party Hub API is running', version: '1.0.0' });
});

// In-memory game state
const activeGames = new Map();
const lobbySockets = new Map(); // lobbyId -> Set of socket IDs

// Generate lobby code
function generateCode() {
  return Math.random().toString(36).substring(2, 6).toUpperCase();
}

// Shuffle array
function shuffle(array) {
  const arr = [...array];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

// Assign roles based on player count and settings
function assignRoles(playerCount, settings) {
  const roles = [];
  const mafiaCount = settings.mafia_count || Math.max(1, Math.floor(playerCount / 3));

  for (let i = 0; i < mafiaCount; i++) roles.push('mafia');
  if (settings.has_doctor !== false) roles.push('doctor');
  if (settings.has_detective !== false) roles.push('detective');

  while (roles.length < playerCount) roles.push('villager');

  return shuffle(roles);
}

// Find game by user ID
function findGameByUser(userId) {
  for (const game of activeGames.values()) {
    if (game.players.some(p => p.userId === userId)) {
      return game;
    }
  }
  return null;
}

// ==================== SOCKET.IO ====================

io.on('connection', (socket) => {
  console.log('User connected:', socket.id);

  // ========== LOBBY ==========

  socket.on('lobby:create', async ({ userId, username, maxPlayers, settings }, callback) => {
    try {
      const code = generateCode();

      const { data: lobby, error } = await supabase
        .from('lobbies')
        .insert({ code, host_id: userId, max_players: maxPlayers || 8 })
        .select()
        .single();

      if (error) throw error;

      await supabase.from('game_settings').insert({
        lobby_id: lobby.id,
        mafia_count: settings?.mafiaCount || 2,
        night_timer: settings?.nightTimer || 20,
        discussion_timer: settings?.discussionTimer || 180,
        vote_timer: settings?.voteTimer || 15,
        has_doctor: settings?.hasDoctor !== false,
        has_detective: settings?.hasDetective !== false,
        spectator_mode: settings?.spectatorMode || 'spectate',
        ghost_chat_enabled: settings?.ghostChatEnabled !== false,
        role_reveal_mode: settings?.roleRevealMode || 'immediate',
        sound_effects_enabled: settings?.soundEffectsEnabled !== false,
        voice_mode: settings?.voiceMode || 'open'
      });

      await supabase.from('lobby_players').insert({
        lobby_id: lobby.id,
        user_id: userId,
        is_ready: false
      });

      socket.join(lobby.id);
      socket.lobbyId = lobby.id;
      socket.userId = userId;
      socket.username = username;

      if (!lobbySockets.has(lobby.id)) {
        lobbySockets.set(lobby.id, new Set());
      }
      lobbySockets.get(lobby.id).add(socket.id);

      callback({ success: true, lobby });
    } catch (err) {
      console.error('lobby:create error:', err);
      callback({ success: false, error: err.message });
    }
  });

  socket.on('lobby:join', async ({ code, userId, username }, callback) => {
    try {
      const { data: lobby, error } = await supabase
        .from('lobbies')
        .select('*, lobby_players(*)')
        .eq('code', code)
        .single();

      if (error || !lobby) {
        return callback({ success: false, error: 'Lobby not found' });
      }

      if (lobby.status !== 'waiting') {
        return callback({ success: false, error: 'Game already started' });
      }

      if (lobby.lobby_players.length >= lobby.max_players) {
        return callback({ success: false, error: 'Lobby is full' });
      }

      const alreadyIn = lobby.lobby_players.some(p => p.user_id === userId);
      if (!alreadyIn) {
        await supabase.from('lobby_players').insert({
          lobby_id: lobby.id,
          user_id: userId
        });
      }

      socket.join(lobby.id);
      socket.lobbyId = lobby.id;
      socket.userId = userId;
      socket.username = username;

      if (!lobbySockets.has(lobby.id)) {
        lobbySockets.set(lobby.id, new Set());
      }
      lobbySockets.get(lobby.id).add(socket.id);

      // Get updated player list
      const { data: players } = await supabase
        .from('lobby_players')
        .select('*, profiles(username, avatar_url)')
        .eq('lobby_id', lobby.id);

      socket.to(lobby.id).emit('lobby:player_joined', {
        userId,
        username,
        players: players.map(p => ({
          userId: p.user_id,
          username: p.profiles?.username || 'Player',
          isReady: p.is_ready,
          isHost: p.user_id === lobby.host_id
        }))
      });

      callback({ success: true, lobby, players });
    } catch (err) {
      console.error('lobby:join error:', err);
      callback({ success: false, error: err.message });
    }
  });

  socket.on('lobby:ready', async ({ ready }) => {
    const { lobbyId, userId } = socket;
    if (!lobbyId) return;

    await supabase
      .from('lobby_players')
      .update({ is_ready: ready })
      .eq('lobby_id', lobbyId)
      .eq('user_id', userId);

    io.to(lobbyId).emit('lobby:player_ready', { userId, ready });
  });

  socket.on('lobby:settings', async ({ settings }) => {
    const { lobbyId, userId } = socket;
    if (!lobbyId) return;

    // Verify host
    const { data: lobby } = await supabase.from('lobbies').select('host_id').eq('id', lobbyId).single();
    if (lobby?.host_id !== userId) return;

    await supabase.from('game_settings').update(settings).eq('lobby_id', lobbyId);
    io.to(lobbyId).emit('lobby:settings_updated', settings);
  });

  // ========== GAME START ==========

  socket.on('game:start', async () => {
    const { lobbyId, userId } = socket;
    if (!lobbyId) return;

    const { data: lobby } = await supabase
      .from('lobbies')
      .select('*, game_settings(*), lobby_players(*)')
      .eq('id', lobbyId)
      .single();

    if (!lobby || lobby.host_id !== userId) return;

    const readyPlayers = lobby.lobby_players.filter(p => p.is_ready);
    if (readyPlayers.length < 4) {
      socket.emit('game:error', { message: 'Need at least 4 ready players' });
      return;
    }

    // Create game
    const { data: game } = await supabase
      .from('games')
      .insert({ lobby_id: lobbyId, status: 'setup' })
      .select()
      .single();

    const players = lobby.lobby_players.filter(p => p.is_ready);
    const roles = assignRoles(players.length, lobby.game_settings);

    for (let i = 0; i < players.length; i++) {
      await supabase.from('game_players').insert({
        game_id: game.id,
        user_id: players[i].user_id,
        role: roles[i]
      });
    }

    await supabase.from('lobbies').update({ status: 'playing' }).eq('id', lobbyId);

    // Store in memory
    activeGames.set(game.id, {
      id: game.id,
      lobbyId,
      round: 0,
      phase: 'setup',
      settings: lobby.game_settings,
      players: players.map((p, i) => ({
        userId: p.user_id,
        username: p.profiles?.username || 'Player',
        role: roles[i],
        alive: true,
        status: 'active'
      })),
      nightActions: {},
      votes: {},
      timers: []
    });

    // Send roles privately
    for (let i = 0; i < players.length; i++) {
      const role = roles[i];
      const mafiaTeammates = roles
        .map((r, idx) => r === 'mafia' ? players[idx].user_id : null)
        .filter(Boolean);

      io.to(lobbyId).emit('game:role_assigned', {
        userId: players[i].user_id,
        role,
        mafiaTeammates: role === 'mafia' ? mafiaTeammates : null,
        message: getRoleMessage(role, mafiaTeammates)
      });
    }

    // Start first night after 5 seconds
    setTimeout(() => startNightPhase(game.id), 5000);
  });

  function getRoleMessage(role, mafiaTeammates) {
    switch (role) {
      case 'mafia':
        return `You are MAFIA! Your teammates: ${mafiaTeammates?.length > 1 ? mafiaTeammates.filter(id => id !== null).join(', ') : 'Working alone'}`;
      case 'doctor':
        return 'You are the DOCTOR! Save someone each night.';
      case 'detective':
        return 'You are the DETECTIVE! Investigate someone each night.';
      default:
        return 'You are a VILLAGER! Find and eliminate the Mafia.';
    }
  }

  // ========== NIGHT PHASE ==========

  socket.on('game:night_action', async ({ targetId }) => {
    const { userId } = socket;
    const game = findGameByUser(userId);
    if (!game) return;

    const player = game.players.find(p => p.userId === userId);
    if (!player || !player.alive) return;
    if (game.phase !== 'night') return;

    game.nightActions[player.role] = targetId;

    // Check if all actions received
    const aliveSpecial = game.players.filter(p => 
      p.alive && ['mafia', 'doctor', 'detective'].includes(p.role)
    );

    const actionsReceived = Object.keys(game.nightActions).length;
    const mafiaAlive = game.players.filter(p => p.role === 'mafia' && p.alive).length;
    const expectedActions = (mafiaAlive > 0 ? 1 : 0) + 
                           (game.players.some(p => p.role === 'doctor' && p.alive) ? 1 : 0) +
                           (game.players.some(p => p.role === 'detective' && p.alive) ? 1 : 0);

    // Notify action received
    socket.emit('game:action_confirmed', { role: player.role });

    if (actionsReceived >= expectedActions) {
      clearTimers(game);
      resolveNightPhase(game);
    }
  });

  // ========== VOTING ==========

  socket.on('game:vote', async ({ targetId }) => {
    const { userId } = socket;
    const game = findGameByUser(userId);
    if (!game) return;

    const player = game.players.find(p => p.userId === userId);
    if (!player || !player.alive) return;
    if (game.phase !== 'voting') return;

    game.votes[userId] = targetId;

    const alivePlayers = game.players.filter(p => p.alive);
    const votesReceived = Object.keys(game.votes).length;

    io.to(game.lobbyId).emit('game:vote_update', {
      votedCount: votesReceived,
      totalAlive: alivePlayers.length,
      hasVoted: Object.keys(game.votes)
    });

    if (votesReceived >= alivePlayers.length) {
      clearTimers(game);
      resolveVotingPhase(game);
    }
  });

  // ========== CHAT ==========

  socket.on('chat:message', async ({ message, chatType }) => {
    const { userId, username } = socket;
    const game = findGameByUser(userId);
    if (!game) return;

    const player = game.players.find(p => p.userId === userId);
    if (!player) return;

    // Validation
    if (!player.alive && chatType !== 'ghost') return;
    if (player.alive && chatType === 'ghost') return;
    if (game.phase === 'night' && chatType === 'alive' && player.alive) return; // No talking at night

    const msgData = {
      game_id: game.id,
      user_id: userId,
      username: username || 'Player',
      message: message.substring(0, 500),
      chat_type: chatType || 'alive',
      created_at: new Date().toISOString()
    };

    await supabase.from('chat_messages').insert(msgData);

    if (chatType === 'ghost') {
      // Only send to ghosts
      game.players.filter(p => !p.alive).forEach(p => {
        io.to(game.lobbyId).emit('chat:new_message', msgData);
      });
    } else {
      io.to(game.lobbyId).emit('chat:new_message', msgData);
    }
  });

  // ========== DISCONNECT ==========

  socket.on('disconnect', async () => {
    console.log('User disconnected:', socket.id);
    const { lobbyId, userId } = socket;

    if (lobbyId && lobbySockets.has(lobbyId)) {
      lobbySockets.get(lobbyId).delete(socket.id);

      // Check if game is active
      const game = findGameByUser(userId);
      if (game) {
        const player = game.players.find(p => p.userId === userId);
        if (player && player.alive) {
          // Mark as disconnected but keep in game
          io.to(lobbyId).emit('game:player_disconnected', { userId });
        }
      }
    }
  });
});

// ==================== GAME PHASE FUNCTIONS ====================

function clearTimers(game) {
  if (game.timers) {
    game.timers.forEach(t => clearTimeout(t));
    game.timers = [];
  }
}

function startNightPhase(gameId) {
  const game = activeGames.get(gameId);
  if (!game) return;

  clearTimers(game);
  game.phase = 'night';
  game.round += 1;
  game.nightActions = {};
  game.votes = {};

  const nightTimer = game.settings.night_timer || 20;

  io.to(game.lobbyId).emit('game:phase_change', {
    phase: 'night',
    round: game.round,
    narrative: 'Night falls... close your eyes',
    soundEffect: 'night_falls',
    timer: nightTimer,
    yourRole: null // Client will show based on stored role
  });

  // Auto-resolve after timer
  const timer = setTimeout(() => {
    if (activeGames.has(gameId) && activeGames.get(gameId).phase === 'night') {
      resolveNightPhase(activeGames.get(gameId));
    }
  }, nightTimer * 1000);

  game.timers = [timer];
}

function resolveNightPhase(game) {
  if (!game) return;
  clearTimers(game);

  const actions = game.nightActions || {};
  const mafiaTarget = actions.mafia;
  const doctorSave = actions.doctor;
  const detectiveCheck = actions.detective;

  let victim = null;
  let saved = false;

  if (mafiaTarget) {
    if (mafiaTarget === doctorSave) {
      saved = true;
    } else {
      victim = mafiaTarget;
      const player = game.players.find(p => p.userId === victim);
      if (player) {
        player.alive = false;
        player.status = 'spectator';
      }
    }
  }

  // Detective result
  let detectiveResult = null;
  if (detectiveCheck) {
    const checked = game.players.find(p => p.userId === detectiveCheck);
    detectiveResult = checked?.role === 'mafia' ? 'mafia' : 'not_mafia';
  }

  // Save to DB
  supabase.from('night_actions').insert({
    game_id: game.id,
    round: game.round,
    mafia_target: mafiaTarget,
    doctor_save: doctorSave,
    detective_check: detectiveCheck,
    resolved: true
  }).then(() => {});

  if (victim) {
    supabase.from('game_players')
      .update({ alive: false, status: 'spectator' })
      .eq('game_id', game.id)
      .eq('user_id', victim).then(() => {});
  }

  game.phase = 'day';

  const victimPlayer = game.players.find(p => p.userId === victim);

  io.to(game.lobbyId).emit('game:night_resolved', {
    victim,
    victimName: victimPlayer?.username || 'Someone',
    saved,
    detectiveResult: detectiveCheck ? {
      checkedId: detectiveCheck,
      isMafia: detectiveResult === 'mafia'
    } : null,
    narrative: saved 
      ? 'The Doctor saved someone! Nobody died.'
      : victim 
        ? `Last night, ${victimPlayer?.username || 'someone'} was killed!`
        : 'Nothing happened last night.',
    soundEffect: saved ? 'saved' : (victim ? 'death' : 'nothing')
  });

  // Start discussion after 3 seconds
  const timer = setTimeout(() => startDiscussionPhase(game), 3000);
  game.timers = [timer];
}

function startDiscussionPhase(game) {
  if (!game) return;
  clearTimers(game);
  game.phase = 'discussion';

  const discussionTimer = game.settings.discussion_timer || 180;

  io.to(game.lobbyId).emit('game:phase_change', {
    phase: 'discussion',
    narrative: 'Discuss who you think is Mafia!',
    soundEffect: 'morning_comes',
    timer: discussionTimer,
    canTalk: true
  });

  const timer = setTimeout(() => startVotingPhase(game), discussionTimer * 1000);
  game.timers = [timer];
}

function startVotingPhase(game) {
  if (!game) return;
  clearTimers(game);
  game.phase = 'voting';
  game.votes = {};

  const voteTimer = game.settings.vote_timer || 15;

  io.to(game.lobbyId).emit('game:phase_change', {
    phase: 'voting',
    narrative: 'Vote for who you think is Mafia!',
    timer: voteTimer,
    canVote: true
  });

  const timer = setTimeout(() => {
    if (activeGames.has(game.id) && activeGames.get(game.id).phase === 'voting') {
      resolveVotingPhase(activeGames.get(game.id));
    }
  }, voteTimer * 1000);

  game.timers = [timer];
}

function resolveVotingPhase(game) {
  if (!game) return;
  clearTimers(game);

  const votes = game.votes || {};
  const voteCounts = {};

  for (const target of Object.values(votes)) {
    voteCounts[target] = (voteCounts[target] || 0) + 1;
  }

  let maxVotes = 0;
  let eliminated = null;
  let tie = false;

  for (const [userId, count] of Object.entries(voteCounts)) {
    if (count > maxVotes) {
      maxVotes = count;
      eliminated = userId;
      tie = false;
    } else if (count === maxVotes) {
      tie = true;
    }
  }

  // If tie, no elimination
  if (tie && Object.keys(voteCounts).length > 1) {
    eliminated = null;
  }

  let eliminatedRole = null;
  if (eliminated) {
    const player = game.players.find(p => p.userId === eliminated);
    if (player) {
      eliminatedRole = player.role;
      player.alive = false;
      player.status = 'spectator';

      supabase.from('game_players')
        .update({ alive: false, status: 'spectator' })
        .eq('game_id', game.id)
        .eq('user_id', eliminated).then(() => {});
    }
  }

  const revealMode = game.settings.role_reveal_mode || 'immediate';

  io.to(game.lobbyId).emit('game:vote_resolved', {
    eliminated,
    eliminatedName: eliminated ? game.players.find(p => p.userId === eliminated)?.username : null,
    eliminatedRole: revealMode === 'immediate' ? eliminatedRole : 'hidden',
    voteCounts,
    tie,
    narrative: eliminated 
      ? `${game.players.find(p => p.userId === eliminated)?.username || 'No one'} was voted out!`
      : tie ? 'It's a tie! No one was eliminated.' : 'No votes cast.',
    soundEffect: eliminated ? 'eliminated' : 'nothing'
  });

  // Check win
  const timer = setTimeout(() => checkWinCondition(game), 3000);
  game.timers = [timer];
}

function checkWinCondition(game) {
  if (!game) return;
  clearTimers(game);

  const mafiaAlive = game.players.filter(p => p.role === 'mafia' && p.alive).length;
  const villageAlive = game.players.filter(p => p.role !== 'mafia' && p.alive).length;

  let winner = null;
  if (mafiaAlive === 0) winner = 'village';
  else if (mafiaAlive >= villageAlive) winner = 'mafia';

  if (winner) {
    game.phase = 'ended';
    game.winner = winner;

    supabase.from('games')
      .update({ status: 'ended', winner })
      .eq('id', game.id).then(() => {});

    // Reveal all roles if hidden mode
    const allRoles = game.settings.role_reveal_mode === 'hidden' 
      ? game.players.map(p => ({ userId: p.userId, role: p.role }))
      : null;

    io.to(game.lobbyId).emit('game:ended', {
      winner,
      narrative: winner === 'mafia' 
        ? 'MAFIA WINS! The village has fallen... 🐺'
        : 'VILLAGERS WIN! Peace is restored! 🎉',
      allRoles,
      players: game.players.map(p => ({
        userId: p.userId,
        username: p.username,
        role: p.role,
        alive: p.alive,
        survived: p.alive
      })),
      soundEffect: winner === 'mafia' ? 'mafia_win' : 'village_win'
    });

    // Clean up after 30 seconds
    setTimeout(() => {
      activeGames.delete(game.id);
      lobbySockets.delete(game.lobbyId);
    }, 30000);
  } else {
    // Next night
    const timer = setTimeout(() => startNightPhase(game.id), 5000);
    game.timers = [timer];
  }
}

// ==================== START SERVER ====================

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log('🚀 AI Party Hub Server running on port ' + PORT);
  console.log('📡 Socket.io ready for connections');
});

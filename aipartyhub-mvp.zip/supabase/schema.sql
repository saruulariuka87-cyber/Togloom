-- AI Party Hub MVP Database Schema
-- Run this in Supabase SQL Editor

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Profiles (extends Supabase Auth users)
CREATE TABLE profiles (
    id UUID REFERENCES auth.users(id) PRIMARY KEY,
    username TEXT UNIQUE NOT NULL,
    avatar_url TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Lobbies
CREATE TABLE lobbies (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    code TEXT UNIQUE NOT NULL,
    host_id UUID REFERENCES profiles(id),
    status TEXT DEFAULT 'waiting',
    max_players INT DEFAULT 8,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Game Settings (per lobby)
CREATE TABLE game_settings (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    lobby_id UUID REFERENCES lobbies(id) ON DELETE CASCADE,
    mafia_count INT DEFAULT 2,
    night_timer INT DEFAULT 20,
    discussion_timer INT DEFAULT 180,
    vote_timer INT DEFAULT 15,
    has_doctor BOOLEAN DEFAULT true,
    has_detective BOOLEAN DEFAULT true,
    spectator_mode TEXT DEFAULT 'spectate',
    ghost_chat_enabled BOOLEAN DEFAULT true,
    role_reveal_mode TEXT DEFAULT 'immediate',
    sound_effects_enabled BOOLEAN DEFAULT true,
    voice_mode TEXT DEFAULT 'open',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Lobby Players
CREATE TABLE lobby_players (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    lobby_id UUID REFERENCES lobbies(id) ON DELETE CASCADE,
    user_id UUID REFERENCES profiles(id),
    is_ready BOOLEAN DEFAULT false,
    joined_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(lobby_id, user_id)
);

-- Games
CREATE TABLE games (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    lobby_id UUID REFERENCES lobbies(id),
    status TEXT DEFAULT 'setup',
    current_round INT DEFAULT 1,
    winner TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Game Players (with roles)
CREATE TABLE game_players (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    game_id UUID REFERENCES games(id) ON DELETE CASCADE,
    user_id UUID REFERENCES profiles(id),
    role TEXT,
    alive BOOLEAN DEFAULT true,
    status TEXT DEFAULT 'active',
    joined_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Night Actions
CREATE TABLE night_actions (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    game_id UUID REFERENCES games(id),
    round INT,
    mafia_target UUID REFERENCES profiles(id),
    doctor_save UUID REFERENCES profiles(id),
    detective_check UUID REFERENCES profiles(id),
    resolved BOOLEAN DEFAULT false
);

-- Chat Messages
CREATE TABLE chat_messages (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    game_id UUID REFERENCES games(id),
    user_id UUID REFERENCES profiles(id),
    message TEXT NOT NULL,
    chat_type TEXT DEFAULT 'alive',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE lobbies ENABLE ROW LEVEL SECURITY;

-- Basic policies
CREATE POLICY "Public profiles" ON profiles FOR SELECT USING (true);
CREATE POLICY "Users can update own profile" ON profiles FOR UPDATE USING (auth.uid() = id);
CREATE POLICY "Public lobbies" ON lobbies FOR SELECT USING (true);

-- Function to auto-create profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO public.profiles (id, username)
    VALUES (new.id, 'Player_' || substr(new.id::text, 1, 5));
    RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger for new user
CREATE OR REPLACE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

import 'package:socket_io_client/socket_io_client.dart' as IO;
import 'package:supabase_flutter/supabase_flutter.dart';

class GameService {
  static final GameService _instance = GameService._internal();
  factory GameService() => _instance;
  GameService._internal();

  IO.Socket? _socket;
  String? _currentLobbyId;
  String? _currentGameId;
  String? _myRole;
  List<String>? _mafiaTeammates;

  IO.Socket? get socket => _socket;
  String? get currentLobbyId => _currentLobbyId;
  String? get currentGameId => _currentGameId;
  String? get myRole => _myRole;
  List<String>? get mafiaTeammates => _mafiaTeammates;

  void connect() {
    if (_socket != null) return;

    _socket = IO.io('http://localhost:3000', IO.OptionBuilder()
      .setTransports(['websocket'])
      .enableAutoConnect()
      .enableReconnection()
      .build());

    _socket!.onConnect((_) {
      print('Connected to server');
    });

    _socket!.onDisconnect((_) {
      print('Disconnected from server');
    });

    _socket!.on('game:role_assigned', (data) {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (data['userId'] == userId) {
        _myRole = data['role'];
        _mafiaTeammates = data['mafiaTeammates'] != null
            ? List<String>.from(data['mafiaTeammates'])
            : null;
      }
    });
  }

  void disconnect() {
    _socket?.disconnect();
    _socket = null;
  }

  // Lobby
  void createLobby(String userId, String username, int maxPlayers, Map<String, dynamic> settings, Function(dynamic) callback) {
    _socket?.emitWithAck('lobby:create', {
      'userId': userId,
      'username': username,
      'maxPlayers': maxPlayers,
      'settings': settings,
    }, ack: callback);
  }

  void joinLobby(String code, String userId, String username, Function(dynamic) callback) {
    _socket?.emitWithAck('lobby:join', {
      'code': code,
      'userId': userId,
      'username': username,
    }, ack: callback);
  }

  void setReady(bool ready) {
    _socket?.emit('lobby:ready', {'ready': ready});
  }

  void updateSettings(Map<String, dynamic> settings) {
    _socket?.emit('lobby:settings', {'settings': settings});
  }

  void startGame() {
    _socket?.emit('game:start');
  }

  // Game actions
  void nightAction(String targetId) {
    _socket?.emit('game:night_action', {'targetId': targetId});
  }

  void vote(String targetId) {
    _socket?.emit('game:vote', {'targetId': targetId});
  }

  // Chat
  void sendMessage(String message, String chatType) {
    _socket?.emit('chat:message', {
      'message': message,
      'chatType': chatType,
    });
  }

  // Listeners
  void on(String event, Function(dynamic) handler) {
    _socket?.on(event, handler);
  }

  void off(String event) {
    _socket?.off(event);
  }

  void setLobbyId(String id) => _currentLobbyId = id;
  void setGameId(String id) => _currentGameId = id;
  void clearRole() {
    _myRole = null;
    _mafiaTeammates = null;
  }
}

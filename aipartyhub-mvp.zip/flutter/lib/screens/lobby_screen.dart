import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../services/game_service.dart';
import 'game_screen.dart';

class LobbyScreen extends StatefulWidget {
  final Map<String, dynamic> lobby;
  final bool isHost;
  final String username;

  const LobbyScreen({
    super.key,
    required this.lobby,
    required this.isHost,
    required this.username,
  });

  @override
  State<LobbyScreen> createState() => _LobbyScreenState();
}

class _LobbyScreenState extends State<LobbyScreen> {
  final GameService _gameService = GameService();
  List<Map<String, dynamic>> _players = [];
  bool _isReady = false;
  bool _gameStarting = false;

  // Settings
  int _maxPlayers = 8;
  int _mafiaCount = 2;
  int _nightTimer = 20;
  int _discussionTimer = 180;
  int _voteTimer = 15;
  bool _hasDoctor = true;
  bool _hasDetective = true;
  bool _ghostChat = true;
  String _roleReveal = 'immediate';
  String _voiceMode = 'open';

  @override
  void initState() {
    super.initState();
    _setupListeners();
    _loadPlayers();
  }

  void _setupListeners() {
    _gameService.on('lobby:player_joined', (data) {
      if (mounted) {
        setState(() {
          _players = List<Map<String, dynamic>>.from(data['players'] ?? []);
        });
      }
    });

    _gameService.on('lobby:player_ready', (data) {
      if (mounted) {
        setState(() {
          final idx = _players.indexWhere((p) => p['userId'] == data['userId']);
          if (idx >= 0) {
            _players[idx]['isReady'] = data['ready'];
          }
        });
      }
    });

    _gameService.on('game:role_assigned', (data) {
      if (mounted && data['userId'] == Supabase.instance.client.auth.currentUser?.id) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (_) => GameScreen(
              role: data['role'],
              mafiaTeammates: data['mafiaTeammates'] != null
                  ? List<String>.from(data['mafiaTeammates'])
                  : null,
            ),
          ),
        );
      }
    });

    _gameService.on('game:error', (data) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(data['message'] ?? 'Error')),
        );
        setState(() => _gameStarting = false);
      }
    });
  }

  void _loadPlayers() {
    final userId = Supabase.instance.client.auth.currentUser?.id;
    _players = [
      {
        'userId': userId,
        'username': widget.username,
        'isReady': false,
        'isHost': widget.isHost,
      }
    ];
  }

  void _toggleReady() {
    setState(() => _isReady = !_isReady);
    _gameService.setReady(_isReady);
  }

  void _startGame() {
    final readyCount = _players.where((p) => p['isReady'] == true).length;
    if (readyCount < 4) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Need at least 4 ready players')),
      );
      return;
    }

    setState(() => _gameStarting = true);
    _gameService.startGame();
  }

  void _showSettings() {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1E1E2E),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => StatefulBuilder(
        builder: (context, setModalState) => Padding(
          padding: const EdgeInsets.all(20),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text(
                  'Game Settings',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 20),
                _buildSetting('Max Players', _maxPlayers.toString(), (v) {
                  setModalState(() => _maxPlayers = v);
                  _updateSettings();
                }, [4, 6, 8, 10, 12, 14, 16]),
                _buildSetting('Mafia Count', _mafiaCount.toString(), (v) {
                  setModalState(() => _mafiaCount = v);
                  _updateSettings();
                }, [1, 2, 3, 4]),
                _buildTimerSetting('Night Timer', _nightTimer, (v) {
                  setModalState(() => _nightTimer = v);
                  _updateSettings();
                }),
                _buildTimerSetting('Discussion', _discussionTimer, (v) {
                  setModalState(() => _discussionTimer = v);
                  _updateSettings();
                }),
                _buildTimerSetting('Vote Timer', _voteTimer, (v) {
                  setModalState(() => _voteTimer = v);
                  _updateSettings();
                }),
                const SizedBox(height: 10),
                _buildToggle('Doctor', _hasDoctor, (v) {
                  setModalState(() => _hasDoctor = v);
                  _updateSettings();
                }),
                _buildToggle('Detective', _hasDetective, (v) {
                  setModalState(() => _hasDetective = v);
                  _updateSettings();
                }),
                _buildToggle('Ghost Chat', _ghostChat, (v) {
                  setModalState(() => _ghostChat = v);
                  _updateSettings();
                }),
                const SizedBox(height: 10),
                _buildDropdown('Role Reveal', _roleReveal, {
                  'immediate': 'Immediate',
                  'hidden': 'Hidden until end',
                }, (v) {
                  setModalState(() => _roleReveal = v!);
                  _updateSettings();
                }),
                _buildDropdown('Voice Mode', _voiceMode, {
                  'open': 'Open Mic',
                  'ptt': 'Push to Talk',
                }, (v) {
                  setModalState(() => _voiceMode = v!);
                  _updateSettings();
                }),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _updateSettings() {
    _gameService.updateSettings({
      'mafiaCount': _mafiaCount,
      'nightTimer': _nightTimer,
      'discussionTimer': _discussionTimer,
      'voteTimer': _voteTimer,
      'hasDoctor': _hasDoctor,
      'hasDetective': _hasDetective,
      'ghostChatEnabled': _ghostChat,
      'roleRevealMode': _roleReveal,
      'voiceMode': _voiceMode,
    });
  }

  @override
  void dispose() {
    _gameService.off('lobby:player_joined');
    _gameService.off('lobby:player_ready');
    _gameService.off('game:role_assigned');
    _gameService.off('game:error');
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final readyCount = _players.where((p) => p['isReady'] == true).length;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Lobby'),
        actions: [
          if (widget.isHost)
            IconButton(
              icon: const Icon(Icons.settings),
              onPressed: _showSettings,
            ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            // Lobby Code
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: const Color(0xFF1E1E2E),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Column(
                children: [
                  const Text(
                    'LOBBY CODE',
                    style: TextStyle(fontSize: 12, color: Colors.grey),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    widget.lobby['code'] ?? 'XXXX',
                    style: const TextStyle(
                      fontSize: 48,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 8,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    '$readyCount/${_players.length} ready',
                    style: TextStyle(color: Colors.white.withOpacity(0.6)),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // Players List
            Expanded(
              child: ListView.builder(
                itemCount: _players.length,
                itemBuilder: (context, index) {
                  final player = _players[index];
                  return Container(
                    margin: const EdgeInsets.only(bottom: 8),
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: const Color(0xFF1E1E2E),
                      borderRadius: BorderRadius.circular(12),
                      border: player['isReady'] == true
                          ? Border.all(color: const Color(0xFF00BFA6))
                          : null,
                    ),
                    child: Row(
                      children: [
                        CircleAvatar(
                          backgroundColor: player['isReady'] == true
                              ? const Color(0xFF00BFA6)
                              : Colors.grey,
                          child: Icon(
                            player['isReady'] == true ? Icons.check : Icons.person,
                            color: Colors.white,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                player['username'] ?? 'Player',
                                style: const TextStyle(fontWeight: FontWeight.bold),
                              ),
                              if (player['isHost'] == true)
                                const Text(
                                  'Host',
                                  style: TextStyle(fontSize: 12, color: Color(0xFF6C63FF)),
                                ),
                            ],
                          ),
                        ),
                        if (player['isReady'] == true)
                          const Chip(
                            label: Text('Ready'),
                            backgroundColor: Color(0xFF00BFA6),
                            labelStyle: TextStyle(color: Colors.white, fontSize: 12),
                          ),
                      ],
                    ),
                  );
                },
              ),
            ),

            // Action Buttons
            if (widget.isHost)
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _gameStarting ? null : _startGame,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF6C63FF),
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  ),
                  child: _gameStarting
                      ? const CircularProgressIndicator(color: Colors.white)
                      : const Text('START GAME', style: TextStyle(fontSize: 16)),
                ),
              )
            else
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _toggleReady,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _isReady ? Colors.orange : const Color(0xFF00BFA6),
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  ),
                  child: Text(
                    _isReady ? 'NOT READY' : 'I'M READY',
                    style: const TextStyle(fontSize: 16),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildSetting(String label, String value, Function(int) onChanged, List<int> options) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label),
          SegmentedButton<int>(
            segments: options.map((o) => ButtonSegment(value: o, label: Text('$o'))).toList(),
            selected: {int.parse(value)},
            onSelectionChanged: (s) => onChanged(s.first),
          ),
        ],
      ),
    );
  }

  Widget _buildTimerSetting(String label, int value, Function(int) onChanged) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label),
          Row(
            children: [
              IconButton(
                icon: const Icon(Icons.remove_circle_outline),
                onPressed: value > 5 ? () => onChanged(value - 5) : null,
              ),
              Text('${value}s'),
              IconButton(
                icon: const Icon(Icons.add_circle_outline),
                onPressed: () => onChanged(value + 5),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildToggle(String label, bool value, Function(bool) onChanged) {
    return SwitchListTile(
      title: Text(label),
      value: value,
      onChanged: onChanged,
      activeColor: const Color(0xFF00BFA6),
    );
  }

  Widget _buildDropdown(String label, String value, Map<String, String> options, Function(String?) onChanged) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label),
          DropdownButton<String>(
            value: value,
            dropdownColor: const Color(0xFF1E1E2E),
            items: options.entries.map((e) => DropdownMenuItem(
              value: e.key,
              child: Text(e.value),
            )).toList(),
            onChanged: onChanged,
          ),
        ],
      ),
    );
  }
}

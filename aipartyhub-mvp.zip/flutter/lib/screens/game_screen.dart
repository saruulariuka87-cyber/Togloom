import 'dart:async';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../services/game_service.dart';

class GameScreen extends StatefulWidget {
  final String role;
  final List<String>? mafiaTeammates;

  const GameScreen({
    super.key,
    required this.role,
    this.mafiaTeammates,
  });

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> {
  final GameService _gameService = GameService();
  String _phase = 'setup';
  String _narrative = '';
  int? _timer;
  Timer? _countdownTimer;
  List<Map<String, dynamic>> _players = [];
  List<Map<String, dynamic>> _messages = [];
  String? _eliminatedPlayer;
  String? _winner;
  String? _myRole;
  bool _iAmAlive = true;
  String _chatType = 'alive';
  final TextEditingController _chatController = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  // Night action
  String? _selectedTarget;
  bool _actionConfirmed = false;

  // Voting
  String? _votedFor;
  Map<String, int> _voteCounts = {};

  @override
  void initState() {
    super.initState();
    _myRole = widget.role;
    _setupListeners();
    _addSystemMessage('Your role: ${_myRole?.toUpperCase()}');
    if (widget.mafiaTeammates != null && widget.mafiaTeammates!.isNotEmpty) {
      _addSystemMessage('Mafia teammates: ${widget.mafiaTeammates!.join(', ')}');
    }
  }

  void _setupListeners() {
    _gameService.on('game:phase_change', (data) {
      if (mounted) {
        setState(() {
          _phase = data['phase'];
          _narrative = data['narrative'] ?? '';
          _timer = data['timer'];
          _eliminatedPlayer = null;
          _selectedTarget = null;
          _actionConfirmed = false;
          _votedFor = null;
          _voteCounts = {};
        });
        _startCountdown(data['timer']);
        _addSystemMessage('${_phase.toUpperCase()} PHASE');
      }
    });

    _gameService.on('game:night_resolved', (data) {
      if (mounted) {
        setState(() {
          _narrative = data['narrative'] ?? '';
          if (data['victim'] != null) {
            _eliminatedPlayer = data['victim'];
            final victimId = data['victim'];
            final idx = _players.indexWhere((p) => p['userId'] == victimId);
            if (idx >= 0) {
              _players[idx]['alive'] = false;
            }
            if (victimId == Supabase.instance.client.auth.currentUser?.id) {
              _iAmAlive = false;
              _chatType = 'ghost';
              _addSystemMessage('You were eliminated! You can now chat with other ghosts.');
            }
          }
        });
      }
    });

    _gameService.on('game:vote_update', (data) {
      if (mounted) {
        setState(() {
          _voteCounts = Map<String, int>.from(data['voteCounts'] ?? {});
        });
      }
    });

    _gameService.on('game:vote_resolved', (data) {
      if (mounted) {
        setState(() {
          _narrative = data['narrative'] ?? '';
          if (data['eliminated'] != null) {
            _eliminatedPlayer = data['eliminated'];
            final idx = _players.indexWhere((p) => p['userId'] == data['eliminated']);
            if (idx >= 0) {
              _players[idx]['alive'] = false;
              _players[idx]['role'] = data['eliminatedRole'];
            }
            if (data['eliminated'] == Supabase.instance.client.auth.currentUser?.id) {
              _iAmAlive = false;
              _chatType = 'ghost';
            }
          }
        });
      }
    });

    _gameService.on('game:ended', (data) {
      if (mounted) {
        setState(() {
          _phase = 'ended';
          _winner = data['winner'];
          _narrative = data['narrative'] ?? '';
          if (data['allRoles'] != null) {
            for (final roleInfo in data['allRoles']) {
              final idx = _players.indexWhere((p) => p['userId'] == roleInfo['userId']);
              if (idx >= 0) {
                _players[idx]['role'] = roleInfo['role'];
              }
            }
          }
        });
      }
    });

    _gameService.on('chat:new_message', (data) {
      if (mounted) {
        setState(() {
          _messages.add({
            'userId': data['userId'],
            'username': data['username'] ?? 'Player',
            'message': data['message'],
            'chatType': data['chat_type'] ?? 'alive',
            'timestamp': data['created_at'] ?? DateTime.now().toIso8601String(),
          });
        });
        _scrollToBottom();
      }
    });

    _gameService.on('game:player_disconnected', (data) {
      _addSystemMessage('${data['userId']} disconnected');
    });
  }

  void _startCountdown(int? seconds) {
    _countdownTimer?.cancel();
    if (seconds == null) return;

    setState(() => _timer = seconds);
    _countdownTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (mounted) {
        setState(() {
          if (_timer != null && _timer! > 0) {
            _timer = _timer! - 1;
          } else {
            timer.cancel();
          }
        });
      }
    });
  }

  void _addSystemMessage(String message) {
    setState(() {
      _messages.add({
        'userId': 'system',
        'username': 'System',
        'message': message,
        'chatType': 'system',
        'timestamp': DateTime.now().toIso8601String(),
      });
    });
    _scrollToBottom();
  }

  void _scrollToBottom() {
    Future.delayed(const Duration(milliseconds: 100), () {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void _submitNightAction() {
    if (_selectedTarget != null && !_actionConfirmed) {
      _gameService.nightAction(_selectedTarget!);
      setState(() => _actionConfirmed = true);
      _addSystemMessage('Action submitted!');
    }
  }

  void _submitVote() {
    if (_votedFor != null) {
      _gameService.vote(_votedFor!);
      _addSystemMessage('Vote submitted!');
    }
  }

  void _sendMessage() {
    final text = _chatController.text.trim();
    if (text.isNotEmpty) {
      _gameService.sendMessage(text, _chatType);
      _chatController.clear();
    }
  }

  String _formatTime(int? seconds) {
    if (seconds == null) return '';
    final m = seconds ~/ 60;
    final s = seconds % 60;
    return '${m.toString().padLeft(2, '0')}:${s.toString().padLeft(2, '0')}';
  }

  Color _getPhaseColor() {
    switch (_phase) {
      case 'night': return const Color(0xFF1a1a3e);
      case 'day': return const Color(0xFF2d1b4e);
      case 'discussion': return const Color(0xFF1E1E2E);
      case 'voting': return const Color(0xFF3d1b1b);
      case 'ended': return const Color(0xFF1E1E2E);
      default: return const Color(0xFF0F0F1E);
    }
  }

  @override
  void dispose() {
    _countdownTimer?.cancel();
    _chatController.dispose();
    _scrollController.dispose();
    _gameService.off('game:phase_change');
    _gameService.off('game:night_resolved');
    _gameService.off('game:vote_update');
    _gameService.off('game:vote_resolved');
    _gameService.off('game:ended');
    _gameService.off('chat:new_message');
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _getPhaseColor(),
      body: SafeArea(
        child: Column(
          children: [
            // Top Bar
            _buildTopBar(),

            // Narrative / Timer
            if (_narrative.isNotEmpty || _timer != null)
              _buildNarrativeBar(),

            // Main Content
            Expanded(
              child: Row(
                children: [
                  // Players List (left side)
                  SizedBox(
                    width: 100,
                    child: _buildPlayersList(),
                  ),

                  // Center Content
                  Expanded(
                    child: _buildCenterContent(),
                  ),
                ],
              ),
            ),

            // Chat
            _buildChatSection(),
          ],
        ),
      ),
    );
  }

  Widget _buildTopBar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.3),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Icon(
                _phase == 'night' ? Icons.nights_stay : Icons.wb_sunny,
                color: _phase == 'night' ? Colors.purple : Colors.orange,
              ),
              const SizedBox(width: 8),
              Text(
                _phase.toUpperCase(),
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          if (_timer != null)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              decoration: BoxDecoration(
                color: _timer! < 10 ? Colors.red.withOpacity(0.3) : Colors.white.withOpacity(0.1),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(
                _formatTime(_timer),
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: _timer! < 10 ? Colors.red : Colors.white,
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildNarrativeBar() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      color: Colors.black.withOpacity(0.2),
      child: Text(
        _narrative,
        textAlign: TextAlign.center,
        style: const TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }

  Widget _buildPlayersList() {
    return ListView.builder(
      itemCount: _players.length,
      itemBuilder: (context, index) {
        final player = _players[index];
        final isMe = player['userId'] == Supabase.instance.client.auth.currentUser?.id;
        final isAlive = player['alive'] != false;
        final role = player['role'];

        return Container(
          margin: const EdgeInsets.all(4),
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: isAlive ? const Color(0xFF1E1E2E) : Colors.grey.withOpacity(0.2),
            borderRadius: BorderRadius.circular(8),
            border: isMe ? Border.all(color: const Color(0xFF6C63FF)) : null,
          ),
          child: Column(
            children: [
              CircleAvatar(
                radius: 20,
                backgroundColor: isAlive
                    ? (role == 'mafia' && !_iAmAlive) ? Colors.red : const Color(0xFF6C63FF)
                    : Colors.grey,
                child: isAlive
                    ? const Icon(Icons.person, size: 20)
                    : const Icon(Icons.close, size: 20),
              ),
              const SizedBox(height: 4),
              Text(
                player['username'] ?? 'P${index + 1}',
                style: TextStyle(
                  fontSize: 10,
                  color: isAlive ? Colors.white : Colors.grey,
                  fontWeight: isMe ? FontWeight.bold : FontWeight.normal,
                ),
                overflow: TextOverflow.ellipsis,
              ),
              if (!_iAmAlive && role != null)
                Text(
                  role.toUpperCase(),
                  style: TextStyle(
                    fontSize: 8,
                    color: role == 'mafia' ? Colors.red : Colors.green,
                  ),
                ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildCenterContent() {
    if (_phase == 'ended') {
      return _buildEndScreen();
    }

    if (_phase == 'night' && _iAmAlive) {
      return _buildNightAction();
    }

    if (_phase == 'voting' && _iAmAlive) {
      return _buildVotingScreen();
    }

    // Discussion / Day / Waiting
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          if (_phase == 'night' && !_iAmAlive)
            const Text(
              '👻 You are watching as a ghost',
              style: TextStyle(color: Colors.grey),
            ),
          if (_phase == 'discussion')
            const Text(
              '💬 Discuss who you think is Mafia!',
              style: TextStyle(fontSize: 18),
            ),
          if (_eliminatedPlayer != null)
            Container(
              margin: const EdgeInsets.all(20),
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.red.withOpacity(0.2),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Text(
                _narrative,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildNightAction() {
    if (_actionConfirmed) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(),
            SizedBox(height: 16),
            Text('Waiting for others...'),
          ],
        ),
      );
    }

    String actionText = '';
    List<Map<String, dynamic>> targets = [];

    switch (_myRole) {
      case 'mafia':
        actionText = 'Choose a victim to eliminate';
        targets = _players.where((p) => p['alive'] != false && p['role'] != 'mafia').toList();
        break;
      case 'doctor':
        actionText = 'Choose someone to save';
        targets = _players.where((p) => p['alive'] != false).toList();
        break;
      case 'detective':
        actionText = 'Choose someone to investigate';
        targets = _players.where((p) => p['alive'] != false).toList();
        break;
      default:
        return const Center(
          child: Text('You are sleeping... zzz', style: TextStyle(color: Colors.grey)),
        );
    }

    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            actionText,
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 20),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            alignment: WrapAlignment.center,
            children: targets.map((target) {
              final isSelected = _selectedTarget == target['userId'];
              return ChoiceChip(
                label: Text(target['username'] ?? 'Player'),
                selected: isSelected,
                onSelected: (_) => setState(() => _selectedTarget = target['userId']),
                selectedColor: const Color(0xFF6C63FF),
                backgroundColor: const Color(0xFF1E1E2E),
              );
            }).toList(),
          ),
          const SizedBox(height: 20),
          ElevatedButton(
            onPressed: _selectedTarget != null ? _submitNightAction : null,
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF6C63FF),
              padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 16),
            ),
            child: const Text('CONFIRM'),
          ),
        ],
      ),
    );
  }

  Widget _buildVotingScreen() {
    if (_votedFor != null) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const CircularProgressIndicator(),
            const SizedBox(height: 16),
            const Text('Vote submitted!'),
            const SizedBox(height: 8),
            Text(
              '${_voteCounts.length} / ${_players.where((p) => p['alive'] != false).length} voted',
              style: TextStyle(color: Colors.white.withOpacity(0.6)),
            ),
          ],
        ),
      );
    }

    final alivePlayers = _players.where((p) => p['alive'] != false).toList();

    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Text(
            'Who is Mafia?',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 20),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            alignment: WrapAlignment.center,
            children: alivePlayers.map((player) {
              final isMe = player['userId'] == Supabase.instance.client.auth.currentUser?.id;
              final isSelected = _votedFor == player['userId'];
              if (isMe) return const SizedBox.shrink();

              return ChoiceChip(
                label: Text(player['username'] ?? 'Player'),
                selected: isSelected,
                onSelected: (_) => setState(() => _votedFor = player['userId']),
                selectedColor: Colors.red,
                backgroundColor: const Color(0xFF1E1E2E),
              );
            }).toList(),
          ),
          const SizedBox(height: 20),
          ElevatedButton(
            onPressed: _votedFor != null ? _submitVote : null,
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 16),
            ),
            child: const Text('VOTE'),
          ),
        ],
      ),
    );
  }

  Widget _buildEndScreen() {
    final isWinner = (_winner == 'mafia' && _myRole == 'mafia') ||
                     (_winner == 'village' && _myRole != 'mafia');

    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            isWinner ? Icons.emoji_events : Icons.sentiment_dissatisfied,
            size: 80,
            color: isWinner ? Colors.amber : Colors.grey,
          ),
          const SizedBox(height: 20),
          Text(
            _narrative,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 20),
          const Text(
            'All Roles:',
            style: TextStyle(fontSize: 16, color: Colors.grey),
          ),
          const SizedBox(height: 10),
          ..._players.map((p) => Padding(
            padding: const EdgeInsets.symmetric(vertical: 2),
            child: Text(
              '${p['username']}: ${p['role']?.toUpperCase() ?? 'UNKNOWN'}',
              style: TextStyle(
                color: p['role'] == 'mafia' ? Colors.red : Colors.white,
                fontWeight: p['userId'] == Supabase.instance.client.auth.currentUser?.id
                    ? FontWeight.bold
                    : FontWeight.normal,
              ),
            ),
          )),
          const SizedBox(height: 30),
          ElevatedButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('BACK TO LOBBY'),
          ),
        ],
      ),
    );
  }

  Widget _buildChatSection() {
    return Container(
      height: 200,
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.3),
        border: Border(
          top: BorderSide(color: Colors.white.withOpacity(0.1)),
        ),
      ),
      child: Column(
        children: [
          // Chat Tabs
          if (!_iAmAlive)
            Row(
              children: [
                Expanded(
                  child: InkWell(
                    onTap: () => setState(() => _chatType = 'ghost'),
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      color: _chatType == 'ghost' ? const Color(0xFF6C63FF) : Colors.transparent,
                      child: const Center(child: Text('👻 Ghost Chat')),
                    ),
                  ),
                ),
                Expanded(
                  child: InkWell(
                    onTap: () => setState(() => _chatType = 'alive'),
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      color: _chatType == 'alive' ? const Color(0xFF6C63FF) : Colors.transparent,
                      child: const Center(child: Text('💬 Alive Chat (Read)')),
                    ),
                  ),
                ),
              ],
            ),

          // Messages
          Expanded(
            child: ListView.builder(
              controller: _scrollController,
              padding: const EdgeInsets.all(8),
              itemCount: _messages.length,
              itemBuilder: (context, index) {
                final msg = _messages[index];
                final isSystem = msg['chatType'] == 'system';
                final isGhost = msg['chatType'] == 'ghost';

                if (isGhost && _iAmAlive) return const SizedBox.shrink();

                return Container(
                  margin: const EdgeInsets.only(bottom: 4),
                  child: Text(
                    isSystem
                        ? msg['message']
                        : '${msg['username']}: ${msg['message']}',
                    style: TextStyle(
                      fontSize: 13,
                      color: isSystem
                          ? Colors.amber
                          : isGhost
                              ? Colors.purple.withOpacity(0.8)
                              : Colors.white,
                      fontStyle: isSystem ? FontStyle.italic : FontStyle.normal,
                    ),
                  ),
                );
              },
            ),
          ),

          // Input
          if (_phase != 'night' || !_iAmAlive)
            Padding(
              padding: const EdgeInsets.all(8),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _chatController,
                      style: const TextStyle(fontSize: 14),
                      decoration: InputDecoration(
                        hintText: _chatType == 'ghost'
                            ? 'Ghost chat...'
                            : 'Type a message...',
                        hintStyle: TextStyle(color: Colors.white.withOpacity(0.4)),
                        filled: true,
                        fillColor: const Color(0xFF1E1E2E),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20),
                          borderSide: BorderSide.none,
                        ),
                        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      ),
                      onSubmitted: (_) => _sendMessage(),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.send),
                    onPressed: _sendMessage,
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

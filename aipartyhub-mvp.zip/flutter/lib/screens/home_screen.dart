import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../services/game_service.dart';
import 'lobby_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final GameService _gameService = GameService();
  bool _isLoading = false;
  String? _username;

  @override
  void initState() {
    super.initState();
    _gameService.connect();
    _initAuth();
  }

  Future<void> _initAuth() async {
    final session = Supabase.instance.client.auth.currentSession;
    if (session == null) {
      final result = await Supabase.instance.client.auth.signInAnonymously();
      if (result.user != null) {
        _username = 'Player_${result.user!.id.substring(0, 5)}';
      }
    } else {
      _username = 'Player_${session.user.id.substring(0, 5)}';
    }
  }

  Future<void> _createLobby() async {
    setState(() => _isLoading = true);

    final user = Supabase.instance.client.auth.currentUser;
    if (user == null || _username == null) {
      setState(() => _isLoading = false);
      return;
    }

    _gameService.createLobby(user.id, _username!, 8, {}, (response) {
      setState(() => _isLoading = false);
      if (response != null && response['success'] == true) {
        _gameService.setLobbyId(response['lobby']['id']);
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => LobbyScreen(
              lobby: response['lobby'],
              isHost: true,
              username: _username!,
            ),
          ),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(response?['error'] ?? 'Failed to create lobby')),
        );
      }
    });
  }

  Future<void> _joinLobby() async {
    final codeController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1E1E2E),
        title: const Text('Join Lobby', style: TextStyle(color: Colors.white)),
        content: TextField(
          controller: codeController,
          style: const TextStyle(color: Colors.white),
          decoration: InputDecoration(
            hintText: 'Enter code (e.g. X7K9)',
            hintStyle: TextStyle(color: Colors.white.withOpacity(0.5)),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
          textCapitalization: TextCapitalization.characters,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              final user = Supabase.instance.client.auth.currentUser;
              if (user == null || _username == null) return;

              Navigator.pop(context);
              setState(() => _isLoading = true);

              _gameService.joinLobby(
                codeController.text.toUpperCase(),
                user.id,
                _username!,
                (response) {
                  setState(() => _isLoading = false);
                  if (response != null && response['success'] == true) {
                    _gameService.setLobbyId(response['lobby']['id']);
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => LobbyScreen(
                          lobby: response['lobby'],
                          isHost: false,
                          username: _username!,
                        ),
                      ),
                    );
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text(response?['error'] ?? 'Failed to join')),
                    );
                  }
                },
              );
            },
            child: const Text('Join'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(24.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Logo
                Container(
                  width: 120,
                  height: 120,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFF6C63FF), Color(0xFF00BFA6)],
                    ),
                    borderRadius: BorderRadius.circular(30),
                  ),
                  child: const Icon(
                    Icons.videogame_asset,
                    size: 60,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 24),
                const Text(
                  'AI PARTY HUB',
                  style: TextStyle(
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 2,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'Voice Mafia',
                  style: TextStyle(
                    fontSize: 18,
                    color: Colors.white.withOpacity(0.6),
                  ),
                ),
                const SizedBox(height: 60),
                if (_isLoading)
                  const CircularProgressIndicator()
                else
                  Column(
                    children: [
                      _buildButton(
                        'CREATE LOBBY',
                        Icons.add_circle,
                        const Color(0xFF6C63FF),
                        _createLobby,
                      ),
                      const SizedBox(height: 16),
                      _buildButton(
                        'JOIN LOBBY',
                        Icons.login,
                        const Color(0xFF00BFA6),
                        _joinLobby,
                      ),
                    ],
                  ),
                const SizedBox(height: 40),
                Text(
                  'Play with 4-16 friends online',
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.4),
                    fontSize: 14,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildButton(String text, IconData icon, Color color, VoidCallback onPressed) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton.icon(
        onPressed: onPressed,
        icon: Icon(icon, size: 24),
        label: Text(
          text,
          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        style: ElevatedButton.styleFrom(
          backgroundColor: color,
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(vertical: 16),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
        ),
      ),
    );
  }
}
